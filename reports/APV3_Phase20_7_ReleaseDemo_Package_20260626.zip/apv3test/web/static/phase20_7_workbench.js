const $ = (id) => document.getElementById(id);

let sessionId = `phase20_7_${Date.now()}`;
let currentTicks = [];
let allTicks = [];
let selectedTickIndex = -1;
let latestReplyText = "";
let autoIdleTimer = null;
let autoIdleDelayMs = 1000;
let idleQuietRuns = 0;
let requestInFlight = false;
let streamItems = [];
let lastInnerPictureTick = null;

const actionNames = {
  observe_text: "读取输入",
  write_cell: "写入草稿",
  commit_reply: "提交回复",
  reply_tts_audio: "本地朗读",
  request_teacher: "请求教学",
  maintain_unclosed: "保留未闭合",
  idle_observe: "闲时观察",
  idle_think: "闲时思考",
  integrate_feedback: "整合教学",
  visual_patch_sensor: "视觉采样",
  move_focus: "移动视焦点",
  audio_audit_sensor: "听觉审计",
  widen_focus: "扩大视野",
  stop_generating: "主动停止",
};

const familyNames = {
  text: "文本",
  user_text: "用户文本",
  draft: "草稿",
  visual_patch: "视觉片段",
  visual_focus: "视焦点",
  audio_audit: "听觉片段",
  tts_actuator: "朗读执行器",
  unclosed_pull: "未闭合牵引",
  feedback: "教学反馈",
};

function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function number(value, digits = 2) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed.toFixed(digits) : "0.00";
}

function percent(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? `${Math.round(parsed * 100)}%` : "0%";
}

async function postJson(url, payload) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return response.json();
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(reader.error || new Error("file_read_failed"));
    reader.readAsDataURL(file);
  });
}

async function uploadMediaFile(file, kind) {
  if (!file) return;
  setStatus(`正在导入${kind === "image" ? "图片" : "音频"}`, "running");
  const dataUrl = await readFileAsDataUrl(file);
  const data = await postJson("/api/phase20/media/upload", {
    name: file.name,
    data_url: dataUrl,
  });
  if (data.error) {
    setStatus(`文件导入失败: ${data.error}`, "sleeping");
    return;
  }
  if (kind === "image") {
    $("imagePath").value = data.path || "";
  } else {
    $("audioPath").value = data.path || "";
  }
  setStatus("文件已导入", "");
}

function mediaUrl(path) {
  const text = String(path || "").trim();
  return text ? `/api/phase20/media?path=${encodeURIComponent(text)}` : "";
}

function setStatus(text, mode = "") {
  $("runtimeStatus").textContent = text;
  $("runtimePulse").textContent = text;
  $("runtimePulse").className = `runtime-pulse ${mode}`.trim();
}

function addMessage(kind, text) {
  const node = document.createElement("div");
  node.className = `message ${kind}`;
  node.textContent = text || "";
  $("chatLog").appendChild(node);
  $("chatLog").scrollTop = $("chatLog").scrollHeight;
}

function addMediaMessage(kind, label, path, mediaType) {
  const node = document.createElement("div");
  node.className = `message ${kind} media`;
  const title = document.createElement("div");
  title.textContent = label;
  node.appendChild(title);
  const url = mediaUrl(path);
  if (mediaType === "image") {
    const img = document.createElement("img");
    img.alt = label;
    img.src = url;
    node.appendChild(img);
  } else if (mediaType === "audio") {
    const audio = document.createElement("audio");
    audio.controls = true;
    audio.preload = "metadata";
    audio.src = url;
    node.appendChild(audio);
  }
  $("chatLog").appendChild(node);
  $("chatLog").scrollTop = $("chatLog").scrollHeight;
}

function buildPayload({ idle = false } = {}) {
  return {
    session_id: sessionId,
    runtime_stage: "stage6",
    text: idle ? "" : $("userText").value.trim(),
    image_path: idle ? "" : $("imagePath").value.trim(),
    audio_path: idle ? "" : $("audioPath").value.trim(),
    teacher_feedback: idle ? "" : $("teacherFeedback").value.trim(),
    post_commit_idle_ticks: idle ? 0 : 1,
    max_ticks: idle ? 8 : 32,
  };
}

async function sendTurn({ idle = false } = {}) {
  if (requestInFlight) return;
  const payload = buildPayload({ idle });
  if (!idle && !payload.text && !payload.image_path && !payload.audio_path && !payload.teacher_feedback) {
    setStatus("没有输入", "sleeping");
    return;
  }

  requestInFlight = true;
  setStatus(idle ? "闲时运行中" : "处理输入中", "running");
  try {
    if (!idle && payload.text) addMessage("user", payload.text);
    if (!idle && payload.image_path) addMediaMessage("user", `输入图片: ${payload.image_path}`, payload.image_path, "image");
    if (!idle && payload.audio_path) addMediaMessage("user", `输入音频: ${payload.audio_path}`, payload.audio_path, "audio");
    if (!idle && payload.teacher_feedback) addMessage("user", `教学: ${payload.teacher_feedback}`);

    const data = await postJson("/api/phase20_7/turn", payload);
    const turn = data.turn || {};
    const ticks = turn.tick_trace || [];
    currentTicks = ticks;
    allTicks = [...allTicks, ...ticks].slice(-260);
    selectedTickIndex = allTicks.length ? allTicks.length - 1 : -1;

    if (turn.reply_text) {
      latestReplyText = turn.reply_text;
      addMessage("ap", turn.reply_text);
      if ($("autoSpeak").checked) speakLatestReply();
    }

    if (!idle) {
      $("userText").value = "";
      $("imagePath").value = "";
      $("audioPath").value = "";
      $("teacherFeedback").value = "";
    }

    renderAll(data, { idle });
    appendStructureStream(ticks, { idle });
    updateIdleCadence(ticks, Boolean(turn.reply_text));
  } catch (error) {
    setStatus("请求失败", "sleeping");
    $("runtimeSummary").textContent = `工作台请求失败: ${String(error)}`;
  } finally {
    requestInFlight = false;
  }
}

function renderAll(data, { idle = false } = {}) {
  const turn = data.turn || {};
  const ticks = turn.tick_trace || [];
  const memory = data.memory || [];
  const unclosed = data.unclosed || [];
  const historyTicks = allTicks.length ? allTicks : ticks;
  renderTicks(historyTicks);
  renderMemory(memory);
  renderUnclosed(unclosed);
  renderInnerPicture(historyTicks);
  renderThoughtCloud(historyTicks, unclosed);
  renderAuditCharts(historyTicks);
  renderStatus(ticks, memory, unclosed, idle);
  renderSelectedTick();
}

function renderStatus(ticks, memory, unclosed, idle) {
  const latest = ticks[ticks.length - 1] || {};
  const action = latest.selected_action || {};
  const stateCount = (latest.state_pool_top || []).length;
  $("metricTick").textContent = String(latest.tick ?? 0);
  $("metricPool").textContent = String(stateCount);
  $("metricMemory").textContent = String((memory || []).length);
  $("metricUnclosed").textContent = String((unclosed || []).length);

  if (idle && action.action_type === "idle_think") {
    setStatus("闲时思考", "running");
  } else if (idle && action.action_type === "idle_observe") {
    setStatus(autoIdleTimer ? "低频待机" : "待机", "sleeping");
  } else {
    setStatus(actionNames[action.action_type] || "完成本轮", "");
  }

  const grasp = latest.cstar_packet?.grasp;
  const u = Math.max(0, ...(latest.unclosed_items || []).map((item) => Number(item.u_value || 0)));
  const visual = latest.visual_inner_picture ? "视觉画面已更新" : "本 tick 无视觉画面";
  $("runtimeSummary").textContent = `最新动作: ${actionNames[action.action_type] || action.action_type || "无"} · 把握 ${number(grasp ?? 0)} · 未闭合 ${number(u)} · ${visual}`;
}

function renderTicks(ticks) {
  if (!ticks.length) {
    $("tickList").innerHTML = `<div class="empty-note">还没有 RuntimeTickEvent。</div>`;
    return;
  }
  $("tickList").innerHTML = ticks.map((tick, index) => {
    const action = tick.selected_action || {};
    const selected = index === selectedTickIndex ? " current" : "";
    const b = (tick.b_candidates || []).slice(0, 3).map((item) => `<span class="tag">B ${candidateName(item)} ${number(item.support)}</span>`).join("");
    const c = [
      ...(tick.c_forward || []).slice(0, 2).map((item) => `<span class="tag">预测 ${candidateName(item)}</span>`),
      ...(tick.c_backward || []).slice(0, 2).map((item) => `<span class="tag">解释 ${candidateName(item)}</span>`),
    ].join("");
    const unclosed = (tick.unclosed_items || []).slice(0, 2).map((item) => `<span class="tag">未闭合 ${esc(item.source_text)} ${number(item.u_value)}</span>`).join("");
    const state = (tick.state_pool_top || []).slice(0, 4).map((item) => esc(readableState(item))).join(" / ");
    return `
      <div class="tick${selected}" data-index="${index}">
        <strong>tick ${esc(tick.tick)} · ${esc(actionNames[action.action_type] || action.action_type || "")}</strong>
        <div>${b}${c}${unclosed || ""}</div>
        <div class="kv">草稿: ${esc((tick.draft_grid || {}).visible_text || "空")}</div>
        <div class="kv">状态池: ${state || "空"}</div>
      </div>
    `;
  }).join("");
  $("tickList").querySelectorAll(".tick[data-index]").forEach((node) => {
    node.addEventListener("click", () => {
      selectedTickIndex = Number(node.getAttribute("data-index"));
      renderTicks(allTicks.length ? allTicks : currentTicks);
      renderSelectedTick();
    });
  });
}

function renderSelectedTick() {
  const historyTicks = allTicks.length ? allTicks : currentTicks;
  const tick = historyTicks[selectedTickIndex] || historyTicks[historyTicks.length - 1];
  if (!tick) {
    $("tickReason").textContent = "选择一个 tick 后，这里会解释 AP 的动作来源。";
    $("draftPreview").textContent = "还没有草稿。";
    return;
  }
  $("tickReason").innerHTML = explainTick(tick);
  const draft = (tick.draft_grid || {}).visible_text || "";
  $("draftPreview").textContent = draft || "草稿格暂时为空。";
  renderTtsStatus(tick);
}

function explainTick(tick) {
  const action = tick.selected_action || {};
  const actionType = action.action_type || "";
  const pieces = [`<p><strong>${esc(actionNames[actionType] || actionType || "未选择动作")}</strong></p>`];

  const inputs = tick.external_inputs || [];
  if (inputs.length) {
    pieces.push(`<p>这一 tick 接到了外部输入: ${inputs.map(inputName).join("、")}。</p>`);
  }

  const receptor = tick.receptor_outputs || [];
  if (receptor.length) {
    pieces.push(`<p>感受器写入了 ${receptor.map(receptorName).join("、")}，这些对象进入状态池和短期结构。</p>`);
  }

  const b = tick.b_candidates || [];
  const forward = tick.c_forward || [];
  const backward = tick.c_backward || [];
  if (b.length) {
    pieces.push(`<p>当前认知召回最强的是 ${candidateName(b[0])}，支持度 ${number(b[0].support)}。</p>`);
  }
  if (forward.length || backward.length) {
    const bits = [];
    if (forward[0]) bits.push(`向后预测 ${candidateName(forward[0])}`);
    if (backward[0]) bits.push(`向前溯源 ${candidateName(backward[0])}`);
    pieces.push(`<p>它同时做了 ${bits.join("，")}，再交给 C* 整合。</p>`);
  }

  const feelings = tick.feelings || {};
  const grasp = tick.cstar_packet?.grasp ?? feelings.grasp ?? feelings.support;
  if (grasp !== undefined) {
    pieces.push(`<p>把握感约 ${number(grasp)}；把握高时更容易写草稿，把握低时更容易请求教学或保留未闭合。</p>`);
  }

  const competition = tick.action_competition || [];
  if (competition.length) {
    const top = competition.slice(0, 4).map((item) => `${actionNames[item.action_type] || item.action_type} ${number(item.drive)}`);
    pieces.push(`<p>行动竞争: ${top.join(" / ")}，最终选中了 ${actionNames[actionType] || actionType}。</p>`);
  }

  const unclosed = tick.unclosed_items || [];
  if (unclosed.length) {
    pieces.push(`<p>未闭合感把注意拉回「${esc(unclosed[0].source_text)}」，U=${number(unclosed[0].u_value)}。</p>`);
  }
  if (feelings.narrative_text) {
    pieces.push(`<p>闲时短期结构流继续到: ${esc(feelings.narrative_text)}。</p>`);
  }

  if (tick.visual_inner_picture) {
    pieces.push(`<p>视觉内心画面来自本 tick 的 patch payload 重建，不是整图识别标签。</p>`);
  }
  if (actionType === "reply_tts_audio") {
    pieces.push(`<p>朗读执行器选择本地 xiaoyi 音色，只记录本地播放意图。</p>`);
  }
  return pieces.join("");
}

function renderInnerPicture(ticks) {
  const tick = [...ticks].reverse().find((item) => item.visual_inner_picture?.path);
  if (tick) {
    lastInnerPictureTick = tick;
  }
  const visibleTick = tick || lastInnerPictureTick;
  if (!visibleTick) {
    $("innerPicture").className = "inner-picture empty";
    $("innerPicture").innerHTML = "等待视觉 tick";
    return;
  }
  const picture = visibleTick.visual_inner_picture;
  $("innerPicture").className = "inner-picture";
  $("innerPicture").innerHTML = `<img alt="AP 内心画面重建" src="${esc(mediaUrl(picture.path))}" title="tick ${esc(visibleTick.tick)} · ${esc(picture.source || "visual_inner_picture")}" />`;
}

function renderThoughtCloud(ticks, unclosedItems) {
  const latest = [...ticks].reverse().find((tick) => (tick.state_pool_top || []).length)
    || ticks[ticks.length - 1]
    || {};
  const thoughts = [];
  for (const item of latest.state_pool_top || []) {
    const energy = Number(item.A || 0) + Number(item.R || 0) + Number(item.V || 0);
    const pressure = Number(item.P || 0);
    thoughts.push({
      text: readableState(item),
      size: 24 + Math.min(50, energy * 18),
      bias: Number(item.R || 0) - Number(item.V || 0),
      energy,
      pressure,
    });
  }
  for (const item of (latest.b_candidates || []).slice(0, 3)) {
    thoughts.push({
      text: `召回 ${candidateName(item)}`,
      size: 30 + Number(item.support || 0) * 24,
      bias: 0.2,
      energy: Number(item.support || 0),
      pressure: Number(item.support || 0) * 0.7,
    });
  }
  for (const item of (unclosedItems || []).slice(0, 3)) {
    thoughts.push({
      text: `还没想明白: ${item.source_text}`,
      size: 34 + Number(item.u_value || 0) * 34,
      bias: -0.4,
      energy: Number(item.u_value || 0),
      pressure: -Number(item.u_value || 0),
    });
  }
  if (!thoughts.length) {
    $("thoughtCloud").innerHTML = `<div class="empty-note">状态池暂时没有可显示的想法对象。</div>`;
    return;
  }
  const positioned = placeThoughts(thoughts.slice(0, 10));
  $("thoughtCloud").innerHTML = positioned.map((thought, index) => {
    const hue = thought.bias >= 0 ? 204 : 36;
    const sat = 35 + Math.min(45, Math.abs(thought.bias) * 60);
    const alpha = 0.52 + Math.min(0.34, thought.energy * 0.12);
    const label = `${thought.text}\n能量 ${number(thought.energy)} · 认知压 ${number(thought.pressure)}`;
    return `<span class="thought" title="${esc(label)}" style="left:${thought.x}%;top:${thought.y}%;font-size:${10 + Math.min(4.8, thought.energy * 0.85)}px;padding:${Math.max(5, thought.size / 8)}px ${Math.max(8, thought.size / 6)}px;background:hsla(${hue}, ${sat}%, 88%, ${alpha});animation-delay:-${index * 0.31}s;--bubble-scale:${number(0.88 + Math.min(0.55, thought.energy * 0.08), 3)};">${esc(thought.text)}</span>`;
  }).join("");
}

function placeThoughts(thoughts) {
  const angles = [0, 55, 110, 165, 220, 275, 330, 28, 83, 138];
  return thoughts.map((thought, index) => {
    const pressureAbs = Math.min(1.8, Math.abs(Number(thought.pressure || 0)));
    const radius = Math.max(7, 39 - pressureAbs * 17 + (index % 4) * 4);
    const angle = (angles[index % angles.length] * Math.PI) / 180;
    return {
      ...thought,
      x: Math.round(Math.max(14, Math.min(86, 50 + Math.cos(angle) * radius)) * 10) / 10,
      y: Math.round(Math.max(16, Math.min(84, 50 + Math.sin(angle) * radius * 0.72)) * 10) / 10,
    };
  });
}

function renderAuditCharts(ticks) {
  const series = [
    {
      title: "状态池对象",
      values: ticks.map((tick) => (tick.state_pool_top || []).length),
      tickLabels: ticks.map((tick) => tick.tick ?? "?"),
      color: "#4776a8",
    },
    {
      title: "草稿长度",
      values: ticks.map((tick) => Number((tick.draft_grid || {}).occupied_cells || 0)),
      tickLabels: ticks.map((tick) => tick.tick ?? "?"),
      color: "#6aa37b",
    },
    {
      title: "未闭合 U",
      values: ticks.map((tick) => Math.max(0, ...(tick.unclosed_items || []).map((item) => Number(item.u_value || 0)))),
      tickLabels: ticks.map((tick) => tick.tick ?? "?"),
      color: "#c08839",
    },
    {
      title: "运行耗时 ms",
      values: ticks.map((tick) => totalTiming(tick.timings_ms || {})),
      tickLabels: ticks.map((tick) => tick.tick ?? "?"),
      color: "#9a6ab8",
    },
    {
      title: "视觉清晰度",
      values: ticks.map((tick) => {
        const receptor = (tick.receptor_outputs || []).find((item) => item.clarity_coverage !== undefined);
        return Number(receptor?.clarity_coverage || 0);
      }),
      tickLabels: ticks.map((tick) => tick.tick ?? "?"),
      color: "#d06c63",
    },
  ];
  $("auditCharts").innerHTML = series.map((item) => renderChart(item)).join("");
  $("auditCharts").querySelectorAll(".chart").forEach((chart) => {
    const tooltip = chart.querySelector(".chart-tooltip");
    chart.addEventListener("mousemove", (event) => {
      if (!tooltip) return;
      const rect = chart.getBoundingClientRect();
      const values = JSON.parse(chart.getAttribute("data-values") || "[]");
      const labels = JSON.parse(chart.getAttribute("data-labels") || "[]");
      const index = Math.max(0, Math.min(values.length - 1, Math.round(((event.clientX - rect.left) / rect.width) * (values.length - 1))));
      tooltip.textContent = `tick ${labels[index] ?? index + 1}: ${number(values[index], 3)}`;
      tooltip.style.left = `${event.clientX - rect.left + 8}px`;
      tooltip.style.top = `${event.clientY - rect.top - 8}px`;
      tooltip.style.display = "block";
    });
    chart.addEventListener("mouseleave", () => {
      if (tooltip) tooltip.style.display = "none";
    });
  });
}

function renderChart({ title, values, tickLabels, color }) {
  const safeValues = values.length ? values : [0];
  const max = Math.max(...safeValues, 0.001);
  const min = Math.min(...safeValues, 0);
  const width = 220;
  const height = 54;
  const points = safeValues.map((value, index) => {
    const x = safeValues.length === 1 ? width : (index / (safeValues.length - 1)) * width;
    const y = height - ((value - min) / Math.max(0.001, max - min)) * (height - 8) - 4;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  const latest = safeValues[safeValues.length - 1] || 0;
  return `
    <div class="chart" data-values="${esc(JSON.stringify(safeValues))}" data-labels="${esc(JSON.stringify(tickLabels || safeValues.map((_, index) => index + 1)))}">
      <div class="chart-label"><span>${esc(title)}</span><strong>${number(latest, 3)}</strong></div>
      <svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" aria-hidden="true">
        <line x1="0" y1="${height - 4}" x2="${width}" y2="${height - 4}" stroke="#e2e8ef" stroke-width="1" />
        <polyline fill="none" stroke="${esc(color)}" stroke-width="2.4" points="${points}" />
        ${safeValues.map((value, index) => {
          const x = safeValues.length === 1 ? width : (index / (safeValues.length - 1)) * width;
          const y = height - ((value - min) / Math.max(0.001, max - min)) * (height - 8) - 4;
          return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="2.2" fill="${esc(color)}" />`;
        }).join("")}
      </svg>
      <div class="chart-tooltip"></div>
    </div>
  `;
}

function renderMemory(items) {
  if (!items || !items.length) {
    $("memoryList").innerHTML = `<div class="empty-note">还没有统一经验记忆。</div>`;
    return;
  }
  $("memoryList").innerHTML = items.map((item) => `
    <div class="memory-item">
      <div><strong>${esc(memoryTypeName(item.processing_tendency))}</strong></div>
      <div>${esc(item.display_text)}</div>
      <div class="kv">support ${number(item.support)} · ${esc(sourceEventName(item.source_event_kind))}</div>
      <button type="button" data-delete="${esc(item.memory_entry_id)}">删除这条记忆</button>
    </div>
  `).join("");
  $("memoryList").querySelectorAll("button[data-delete]").forEach((button) => {
    button.addEventListener("click", async () => {
      await postJson("/api/phase20_7/memory/delete", {
        memory_entry_id: button.getAttribute("data-delete"),
        reason: "workbench_delete",
      });
      await refreshMemory();
    });
  });
}

function renderUnclosed(items) {
  if (!items || !items.length) {
    $("unclosedList").innerHTML = `<div class="empty-note">暂时没有被未闭合感拉住的问题。</div>`;
    return;
  }
  $("unclosedList").innerHTML = items.map((item) => `
    <div class="memory-item">
      <div>${esc(item.source_text)}</div>
      <div class="kv">U ${number(item.u_value)} · 尝试 ${esc(item.attempt_count)}</div>
    </div>
  `).join("");
}

async function refreshMemory() {
  const data = await postJson("/api/phase20_7/memory/list", { limit: 200, session_id: sessionId });
  renderMemory(data.items || []);
  renderUnclosed(data.unclosed || []);
  $("metricMemory").textContent = String((data.items || []).length);
  $("metricUnclosed").textContent = String((data.unclosed || []).length);
}

async function speakLatestReply() {
  if (!latestReplyText) {
    $("ttsStatus").textContent = "还没有可朗读的最新回复。";
    return;
  }
  const spoken = await speakWithBrowserXiaoyi(latestReplyText);
  if (spoken) {
    return;
  }
  $("ttsStatus").textContent = "浏览器没有检测到可用的 xiaoyi/中文本地语音；后端 SAPI 当前也未发现 xiaoyi。不会调用云端，也不会伪造音频。";
}

async function speakWithBrowserXiaoyi(text) {
  if (!("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)) {
    return false;
  }
  const voices = await loadBrowserVoices();
  const voice = voices.find((item) => /xiaoyi|xiao yi|晓伊|晓艺|小艺|小依/i.test(`${item.name || ""} ${item.voiceURI || ""}`))
    || voices.find((item) => /zh|chinese|mandarin/i.test(`${item.lang || ""} ${item.name || ""}`));
  if (!voice) return false;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.voice = voice;
  utterance.lang = voice.lang || "zh-CN";
  utterance.rate = 1.0;
  utterance.pitch = 1.0;
  $("ttsStatus").textContent = `浏览器本地朗读中 · ${voice.name || "xiaoyi"}`;
  window.speechSynthesis.speak(utterance);
  return true;
}

function loadBrowserVoices() {
  return new Promise((resolve) => {
    const voices = window.speechSynthesis.getVoices();
    if (voices.length) {
      resolve(voices);
      return;
    }
    const timer = window.setTimeout(() => resolve(window.speechSynthesis.getVoices()), 800);
    window.speechSynthesis.onvoiceschanged = () => {
      window.clearTimeout(timer);
      resolve(window.speechSynthesis.getVoices());
    };
  });
}

function renderTtsStatus(tick) {
  const action = tick.selected_action || {};
  if (action.action_type === "reply_tts_audio") {
    $("ttsStatus").textContent = `AP 产生了本地朗读意图: ${action.voice_preference || "xiaoyi"}。`;
  }
}

function updateIdleCadence(ticks, spoke) {
  if (!autoIdleTimer) return;
  const action = (ticks[ticks.length - 1] || {}).selected_action || {};
  const interesting = spoke || action.action_type === "idle_think" || (ticks[ticks.length - 1]?.unclosed_items || []).length > 0;
  idleQuietRuns = interesting ? 0 : idleQuietRuns + 1;
  const nextDelay = idleQuietRuns >= 5 ? 5000 : idleQuietRuns >= 3 ? 2500 : 1000;
  if (nextDelay !== autoIdleDelayMs) {
    stopAutoIdle(false);
    startAutoIdle(nextDelay);
  }
}

function startAutoIdle(delay = 1000) {
  autoIdleDelayMs = delay;
  $("autoIdle").setAttribute("aria-pressed", "true");
  $("autoIdle").textContent = delay > 1000 ? "连续闲时: 低频" : "连续闲时: 开";
  autoIdleTimer = window.setInterval(() => sendTurn({ idle: true }), delay);
  setStatus(delay > 1000 ? "低频待机" : "连续闲时", delay > 1000 ? "sleeping" : "running");
}

function stopAutoIdle(updateButton = true) {
  if (autoIdleTimer) window.clearInterval(autoIdleTimer);
  autoIdleTimer = null;
  if (updateButton) {
    $("autoIdle").setAttribute("aria-pressed", "false");
    $("autoIdle").textContent = "连续闲时";
    setStatus("待机", "sleeping");
  }
}

function toggleAutoIdle() {
  if (autoIdleTimer) {
    stopAutoIdle();
    return;
  }
  idleQuietRuns = 0;
  startAutoIdle(1000);
  sendTurn({ idle: true });
}

function latestIdleThought(ticks) {
  const tick = ticks[ticks.length - 1] || {};
  const item = (tick.unclosed_items || [])[0];
  if (!item) return "";
  return `还在想「${item.source_text}」`;
}

function appendStructureStream(ticks, { idle = false } = {}) {
  const fresh = [];
  for (const tick of ticks || []) {
    const action = tick.selected_action || {};
    const summary = structureSummary(tick, { idle });
    if (!summary) continue;
    fresh.push({
      tick: tick.tick ?? "?",
      action: actionNames[action.action_type] || action.action_type || "tick",
      summary,
    });
  }
  if (!fresh.length) return;
  streamItems = [...fresh.reverse(), ...streamItems];
  streamItems = streamItems.slice(0, 24);
  $("structureStream").innerHTML = streamItems.map((item) => `
    <div class="stream-item">
      <strong>tick ${esc(item.tick)} · ${esc(item.action)}</strong>
      <div>${esc(item.summary)}</div>
    </div>
  `).join("");
}

function structureSummary(tick, { idle = false } = {}) {
  const action = tick.selected_action || {};
  const ssp = tick.ssp_active_summary || {};
  const query = (tick.query_structures || [])[0] || {};
  const unclosed = (tick.unclosed_items || [])[0];
  const b = (tick.b_candidates || [])[0];
  const visual = (tick.receptor_outputs || []).find((item) => item.receptor === "visual_patch_sensor");
  if (idle && (tick.feelings || {}).narrative_text) {
    return `短期结构流续写: ${(tick.feelings || {}).narrative_text}`;
  }
  if (idle && unclosed) {
    return `未闭合感把短期结构流拉回「${unclosed.source_text}」，U=${number(unclosed.u_value)}。`;
  }
  if (visual) {
    return `视觉结构流更新: focus=${(visual.focus_xy || []).join(",")}，clarity=${percent(visual.clarity_coverage)}。`;
  }
  if (query.signature || ssp.signature) {
    const kind = query.structure_kind || ssp.structure_kind || "结构";
    const visualSig = query.visual_signature ? "，已绑定本轮视觉证据" : "";
    return `${kind} 更新: ${query.unit_count || ssp.active_occurrence_count || 0} 个单元${visualSig}。`;
  }
  if (b) {
    return `召回 ${candidateName(b)}，支持度 ${number(b.support)}。`;
  }
  return action.action_type ? `行动竞争选中 ${actionNames[action.action_type] || action.action_type}。` : "";
}

function inputName(item) {
  const kind = item.input_kind || item.media_type || "输入";
  if (kind === "text") return `文本 ${item.char_length || 0} 字`;
  if (kind === "image") return "图片";
  if (kind === "audio") return "音频";
  return esc(kind);
}

function receptorName(item) {
  const receptor = item.receptor || "感受器";
  if (receptor === "text") return `文本感受器 ${item.unit_count || 0} 单元`;
  if (receptor === "visual_patch_sensor") return `视觉 patch ${percent(item.clarity_coverage)}`;
  if (receptor === "audio_audit_sensor") return `听觉审计 ${number(item.duration_ms, 1)} ms`;
  return receptor;
}

function candidateName(item) {
  const kind = item.kind || "";
  if (kind === "exact_b0") return "精确经验";
  if (kind === "structural_b") return "结构相似经验";
  if (kind === "sequence_forward_prediction") return "序列后继";
  if (kind === "source_structure_explanation") return "来源解释";
  return kind || "候选";
}

function readableState(item) {
  const family = familyNames[item.family] || item.family || "对象";
  const label = item.label || item.sa_id || "";
  return `${family}:${label}`;
}

function memoryTypeName(value) {
  if (value === "exact_recall") return "精确记忆";
  if (value === "structural_recall") return "结构记忆";
  if (value === "package_member") return "记忆包";
  return value || "经验记忆";
}

function sourceEventName(value) {
  if (value === "experience_alignment") return "教学对齐";
  if (value === "text_observation") return "文本观察";
  if (value === "visual_patch_sample") return "视觉采样";
  if (value === "audio_audit_sample") return "听觉审计";
  return value || "";
}

function totalTiming(timings) {
  return Object.values(timings || {}).reduce((sum, value) => {
    const parsed = Number(value);
    return sum + (Number.isFinite(parsed) ? parsed : 0);
  }, 0);
}

$("sendTurn").addEventListener("click", () => sendTurn());
$("idleTurn").addEventListener("click", () => sendTurn({ idle: true }));
$("autoIdle").addEventListener("click", toggleAutoIdle);
$("playTts").addEventListener("click", speakLatestReply);
$("clearInput").addEventListener("click", () => {
  $("userText").value = "";
  $("imagePath").value = "";
  $("audioPath").value = "";
  $("teacherFeedback").value = "";
});
$("refreshMemory").addEventListener("click", refreshMemory);
$("userText").addEventListener("keydown", (event) => {
  if (event.isComposing) return;
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendTurn();
  }
});
$("teacherFeedback").addEventListener("keydown", (event) => {
  if (event.isComposing) return;
  if (event.key === "Enter") {
    event.preventDefault();
    sendTurn();
  }
});
$("imageFile").addEventListener("change", (event) => uploadMediaFile(event.target.files?.[0], "image"));
$("audioFile").addEventListener("change", (event) => uploadMediaFile(event.target.files?.[0], "audio"));

refreshMemory();
